package source;
import javax.swing.*;
import javax.swing.event.*;

import java.awt.Image;
import java.awt.event.*;
import java.net.URL;

class SourceCode {
	private static float OnPress(float CurrentValue, float UpdateFactor, String Type) {
		if (Type == "Add") {
			CurrentValue = CurrentValue + UpdateFactor;
		} else if(Type=="Multiply") {
			if (UpdateFactor>1) {
				CurrentValue = CurrentValue * UpdateFactor;
			} else {
				CurrentValue = (float)(CurrentValue * 1.1);
			}
		}
		return CurrentValue;
	}
	
	private static boolean NumericParsing(String str) {
		if (str == null || str.isEmpty()) {
			return false;
		}
		try {
			Float.parseFloat(str);
			return true;
		} catch (NumberFormatException e) {
			return false;
		}
	}
	
	private static JFrame Window = new JFrame();
	private static JPanel Panel = new JPanel();
	private static JButton IncreaseMoney = new JButton();
	private static JButton TypeAdd = new JButton();
	private static JButton TypeMultiply = new JButton();
	private static JLabel CurrencyValue = new JLabel();
	private static JTextField FactorValue = new JTextField();
	private static JLabel version = new JLabel();
	public static float Currency = 0;
	private static String Type = "Add";
	private static float Factor = 1;
	private static  void CreateWindow() {
		Window.setVisible(true); Window.setResizable(false); Window.setTitle("Cat's Clicker v.0.0.1 (Pre-Alpha)"); Window.setSize(500,500); Window.add(Panel);
		Window.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.out.println("Process closed with exit code 0.");
				System.exit(0);
			}
		});
		Panel.add(IncreaseMoney); Panel.add(CurrencyValue); Panel.add(TypeAdd); Panel.add(TypeMultiply); Panel.add(FactorValue); Panel.add(version);
		Panel.setLayout(null);
		TypeAdd.setBounds(125,225,100,30); TypeAdd.setText("Add");
		TypeMultiply.setBounds(275,225,100,30); TypeMultiply.setText("Multiply");
		CurrencyValue.setBounds(213,50,200,30); CurrencyValue.setText("Currency: 0");
		IncreaseMoney.setBounds(150,400,200, 30); IncreaseMoney.setText("Increase your Currency!");
		FactorValue.setBounds(175,300,150,30); FactorValue.setText("Value to "+Type+" by..."); FactorValue.setHorizontalAlignment(JTextField.CENTER);
		
		version.setBounds(5,440,400,20); version.setText("v.0.0.1 pre-alpha (contact catsaccount on Discord for updates)");
	}

	public static void main(String[] args) {
		CreateWindow();
		IncreaseMoney.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Currency = (float)Math.floor(OnPress(Currency, Factor, Type)*100)/100;
				CurrencyValue.setText("Currency: "+Currency);
			}
			
		});
		TypeAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Type = "Add";
				if (NumericParsing(FactorValue.getText())) {
					return;
				}
				FactorValue.setText("Value to "+Type+" by...");
			}
		});
		TypeMultiply.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Type = "Multiply";
				if (NumericParsing(FactorValue.getText())) {
					return;
				}
				FactorValue.setText("Value to "+Type+" by...");
			}
		});
		FactorValue.addFocusListener(new FocusAdapter() {
			public void focusGained(FocusEvent e) {
				FactorValue.setText("");
			}
			public void focusLost(FocusEvent e) {
				if (NumericParsing(FactorValue.getText())) {
					return;
				}
				FactorValue.setText("Value to "+Type+" by...");
			}
		});
		FactorValue.getDocument().addDocumentListener(new DocumentListener() {
			public void insertUpdate(DocumentEvent e) {
				if (NumericParsing(FactorValue.getText())) {
					Factor = Math.clamp(Float.parseFloat(FactorValue.getText()), 0, 9000);
				}
			}
			public void removeUpdate(DocumentEvent e) {
				if (NumericParsing(FactorValue.getText())) {
					Factor = Math.clamp(Float.parseFloat(FactorValue.getText()), 0, 9000);
				}
			}
			public void changedUpdate(DocumentEvent e) {
				return;
			}
		});
	}
}
