/**
 * 
 */
/**
 * 
 */
module Clicking {
	requires java.desktop;
	
}